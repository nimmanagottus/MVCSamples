﻿using System;
using System.Configuration;
using System.IO;
using System.ServiceProcess;
using System.Threading;
using System.Timers;

namespace Store
{
    public partial class Store : ServiceBase
    {
        private System.Threading.Timer Schedular;
        public Store()
        {
            InitializeComponent();

        }

        public void OnDebug()
        {
            OnStart(null);
        }

        protected override void OnStart(string[] args)
        {
            this.WriteToFile("Store Service started: {0}");
            this.ScheduleService();
        }
        protected override void OnStop()
        {
            this.WriteToFile("Store Service stopped: {0}");
            this.Schedular.Dispose();
        }

        public void ScheduleService()
        {
            try
            {
                Schedular = new System.Threading.Timer(new TimerCallback(SchedularCallback));
                string mode = ConfigurationManager.AppSettings["Mode"].ToUpper();
                this.WriteToFile("Store Service Mode: " + mode + " {0}");
                //Set the Default Time.
                DateTime scheduledTime = DateTime.MinValue;
                # region DAILY
                if (mode == "DAILY")
                {
                    //Get the Scheduled Time from AppSettings.
                    scheduledTime = DateTime.Parse(ConfigurationManager.AppSettings["ScheduledTime"]);
                    if (DateTime.Now > scheduledTime)
                    {
                        this.BusinessLogic();
                        //If Scheduled Time is passed set Schedule for the next day.
                        scheduledTime = scheduledTime.AddDays(1);
                    }
                }
                #endregion

                #region INTERVAL
                //if (mode.ToUpper() == "INTERVAL")
                //{
                //    //Get the Interval in Minutes from AppSettings.
                //    int intervalMinutes = Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]);

                //    //Set the Scheduled Time by adding the Interval to Current Time.
                //    scheduledTime = DateTime.Now.AddMinutes(intervalMinutes);
                //    if (DateTime.Now > scheduledTime)
                //    {
                //        //If Scheduled Time is passed set Schedule for the next Interval.
                //        scheduledTime = scheduledTime.AddMinutes(intervalMinutes);
                //    }
                //}
                #endregion
                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds(s)", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                this.WriteToFile("Store Service scheduled to run after: " + schedule + " {0}");
                //Get the difference in Minutes between the Scheduled and Current Time.
                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);
                //Change the Timer's Due Time.
                Schedular.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                WriteToFile("Store Service Error on: {0} " + ex.Message + ex.StackTrace);

                //Stop the Windows Service.
                using (System.ServiceProcess.ServiceController serviceController = new System.ServiceProcess.ServiceController("StoreService"))
                {
                    serviceController.Stop();
                }
            }
        }

        private void SchedularCallback(object e)
        {
            this.WriteToFile("Store Service Log: {0}");
            this.ScheduleService();
        }

        private void WriteToFile(string text)
        {
            string path = "D:\\ServiceLog.txt";
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine("################################################################");
                writer.WriteLine(string.Format(text, DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt")));
                writer.WriteLine("################################################################");
                writer.Close();
            }
        }

        private void BusinessLogic()
        {
            string path = "D:\\ServiceLog.txt";
            using (var tw = new StreamWriter(path, true))
            {
                tw.WriteLine("The next line!");
                tw.Close();
            }

        }
       
    }
}
