﻿namespace Store
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StoreServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.StoreServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // StoreServiceProcessInstaller
            // 
            this.StoreServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
            this.StoreServiceProcessInstaller.Password = null;
            this.StoreServiceProcessInstaller.Username = null;
            // 
            // StoreServiceInstaller
            // 
            this.StoreServiceInstaller.ServiceName = "MyStoreService";
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.StoreServiceProcessInstaller,
            this.StoreServiceInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller StoreServiceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller StoreServiceInstaller;
    }
}